<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>freelance.com</title>
     <!-- <link rel="stylesheet" href="../css/login.css">  -->
     <link rel="stylesheet" href="../css/sign up.css">
     <link rel="stylesheet" href="../css/Admin.css">
</head>
<body>
  <header class="head">
     <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo"> Freelance</h2>
            </div>
            <div class="menu">
                <ul>
                 <li><a href="#">Home</a></li>
                 <li><a href="#">About</a></li>
                 <li><a href="#">Signup</a></li>
                 <li><a href="#">Service</a></li>
                
               </ul>
            </div>
              
            <div class="search">
                <input  class = "srch" type="search" name "" placeholder="Type to text" >
                <a href="#"><button class="btn">Search</button></a>
           </div>
       </div>
       </div>
</header> 
<main >
    <div class="start"> 
         <div class="wel"> 
           <p>Welcome In The Admin Page</p>
        </div>
         <div class="you">
          <p>You Can Choose What data You Want To Check..</p>
         </div>
      </div>
    </div>

    <div class="choose">
           <div class="client"><a href="Clients.php">Clients</a></div>
           <div class="free"><a href="Freelancers.php">Freelancers</a></div>
           <div class="post"><a href=# >Posts </a></div>
         
        
    </div>


</main>
</body>
</html>