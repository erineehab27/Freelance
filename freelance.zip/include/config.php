<?php 
include 'db.php';

if(isset($_POST['submit'])){

    $sql = "SELECT email , pass FROM users WHERE email = '{$_POST['email']}' AND  pass = {$_POST['pass']}";
    $result = $conn->query($sql);
    if($row = $result->fetch_assoc()){
        header("Location: ../html/client.php "); 
    }else{
        header("Location: ../html/Login.php?connection-failed");
    }
} 




?> 