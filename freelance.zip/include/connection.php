<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clientform";
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error){
    die("ERROR: Could not connect. " . $conn->connect_error);
}

// Taking all 2 values from the form data(input)
if(isset($_POST['save'])){ 
$project_name = isset($_POST['project_name']) ? $_POST['project_name'] : "";
$describtion = isset($_POST['describtion']) ? $_POST['describtion'] : "";
$btt = isset($_POST['btt']) ? $_POST['btt'] : "";

echo $project_name;

$sql = "INSERT INTO form (project_name, describtion, btt) VALUES ('$project_name','$describtion','$btt')";

$result = mysqli_query($conn, $sql);
if($result){
    header("Location:../html/wall.php");
} else{
    echo "ERROR: Hush! Sorry $sql. " 
        . mysqli_error($conn);
}
  

mysqli_close($conn);
}
?>







