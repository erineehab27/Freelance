<?php
$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "clientform";
//$conn = new mysqli();
$conn=new mysqli($serverName, $dbUsername, $dbPassword, $dbName);
?>