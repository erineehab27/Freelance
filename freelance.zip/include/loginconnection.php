<? php 

$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "clientform";

$conn = new mysqli();
$conn->connect($serverName, $dbUsername, $dbPassword, $dbName);

//if conn failed
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit'])){

    $sql = "SELECT email , pass FROM users WHERE email = '{$_POST['email']}' AND  pass = {$_POST['pass']}";
    $result = $conn->query($sql);
    if($row = $result->fetch_assoc()){
        header("Location:sign.php "); 
    }else{
        header("Location: Login.php?connection-failed");
    }
} 




?> 